package com.re.simplenem12.model;
/**
 * Represents meter read quality in SimpleNem12
 */
public enum Quality {

  A,
  E
  
}
