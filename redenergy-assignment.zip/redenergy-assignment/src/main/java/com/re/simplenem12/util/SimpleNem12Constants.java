package com.re.simplenem12.util;

public class SimpleNem12Constants {
	public static final String INVALID_ENERGY_UNIT = "KWH unit is allowed for EnergyUnit.";
	public static final String INVALID_QUANTITY = "Quantity value should always be A or E.";
	public static final String INVALID_VOLUME = "Volume should be a valid number.";
	public static final String INVALID_DATE_FORMAT = "Date format should be yyyyMMdd.";
	public static final String INVALID_NMI = "NMI value should be 10 chars long.";
	public static final String BLANK_RECORD = "Record is blank.";
	public static final String BLANK_MANDATORY_FIELD = "Mandatory field is blank.";
	public static final String DATE_PATTERN = "yyyyMMdd";
	public static final String COMMA_SEPARATOR = ",";
}
