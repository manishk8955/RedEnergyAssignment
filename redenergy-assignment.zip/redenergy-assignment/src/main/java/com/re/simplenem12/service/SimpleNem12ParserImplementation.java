package com.re.simplenem12.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.re.simplenem12.util.SimpleNem12Constants;
import com.re.simplenem12.util.SimpleNem12Util;
import com.re.simplenem12.model.EnergyUnit;
import com.re.simplenem12.model.MeterRead;
import com.re.simplenem12.model.MeterVolume;
import com.re.simplenem12.model.Quality;

public class SimpleNem12ParserImplementation implements SimpleNem12Parser {

    private final List<MeterRead> meterReadingList = new ArrayList<>();   
    private static Logger log = LoggerFactory.getLogger(SimpleNem12ParserImplementation.class);

    public Collection<MeterRead> parseSimpleNem12(File simpleNem12File) {
        try (InputStream inputFileStream = new FileInputStream(simpleNem12File);
             BufferedReader br = new BufferedReader(new InputStreamReader(inputFileStream))) {
            br.lines().forEach(this::parseLine);
        } catch (Exception e) {
            log.error(String.format(e.getMessage()));  
            System.err.println(e.getMessage());
        }
        return meterReadingList;
    }

    private void parseLine(String line) {
        if (!StringUtils.isBlank(line)) {
            String[] record = line.split(SimpleNem12Constants.COMMA_SEPARATOR);
            if (SimpleNem12Util.isHeaderRecordValid(record)) {
                addMeterReadRec(record);
            }
            if (SimpleNem12Util.isDataRecordValid(record)) {
                if (meterReadingList.size() > 0) {
                    addMeterVolumeRec(record);
                }
            }
        }
    }

    private void addMeterVolumeRec(String[] record) {
        MeterVolume meterVolume = new MeterVolume(new BigDecimal(record[2].trim()),
                Quality.valueOf(record[3].trim()));
        meterReadingList.get(meterReadingList.size() - 1).getVolumes().put(SimpleNem12Util.checkDateFormat(record[1].trim()), meterVolume);
    }

    private void addMeterReadRec(String[] record) {
        MeterRead meterReadRec = new MeterRead(record[1].trim(), EnergyUnit.valueOf(record[2].trim()));
        meterReadingList.add(meterReadRec);
    }

}