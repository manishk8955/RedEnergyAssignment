package com.re.simplenem12.model;

public enum RecordType {

    FIRST_RECORD("100"),
    METER_NUMBER_RECORD("200"),
    METER_READ_RECORD("300"),
    LAST_RECORD("900");

    private final String value;

    RecordType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
