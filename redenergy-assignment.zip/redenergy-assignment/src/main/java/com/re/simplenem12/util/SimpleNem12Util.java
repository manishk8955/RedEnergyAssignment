package com.re.simplenem12.util;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import org.apache.commons.lang3.StringUtils;
import com.re.simplenem12.model.EnergyUnit;
import com.re.simplenem12.model.RecordType;
import com.re.simplenem12.model.Quality;

public class SimpleNem12Util {

	public static boolean isHeaderRecordValid(String[] record) {
		if (isFieldValid(record) && RecordType.METER_NUMBER_RECORD.getValue().equals(record[0].trim())) {
			if (record[1].trim().length() != 10) {
				System.err.println(printArray(record) + SimpleNem12Constants.INVALID_NMI);
				return false;
			}
			if (!EnergyUnit.KWH.name().equals(record[2].trim())) {
				System.err.println(printArray(record) + SimpleNem12Constants.INVALID_ENERGY_UNIT);
				return false;
			}
		} else {
			return false;
		}
		return true;
	}

	public static boolean isDataRecordValid(String[] record) {
		if (isFieldValid(record) && RecordType.METER_READ_RECORD.getValue().equals(record[0].trim())) {

			if (!isDateValid(record[1].trim())) {
				System.err.println(printArray(record) + SimpleNem12Constants.INVALID_DATE_FORMAT);
				return false;
			}

			if (!isVolumeRecValid(record[2].trim())) {
				System.err.println(printArray(record) + SimpleNem12Constants.INVALID_VOLUME);
				return false;
			}
			if (!isQuantityRecValid(record[3].trim())) {
				System.err.println(printArray(record) + SimpleNem12Constants.INVALID_QUANTITY);
				return false;
			}
		} else {
			return false;
		}
		return true;
	}

	public static boolean isFieldValid(String[] record) {
		if (!StringUtils.isAllBlank(record)) {
			for (String col : record) {
				if (StringUtils.isBlank(col)) {
					System.err.println(printArray(record) + SimpleNem12Constants.BLANK_MANDATORY_FIELD);
					return false;
				}
			}
		} else {
			System.err.println(printArray(record) + SimpleNem12Constants.BLANK_RECORD);
			return false;
		}
		return true;
	}

	private static boolean isVolumeRecValid(String col) {
		try {
			new BigDecimal(col);
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	private static boolean isDateValid(String col) {
		try {
			SimpleNem12Util.checkDateFormat(col);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static LocalDate checkDateFormat(String dateString) {
		return LocalDate.parse(dateString, DateTimeFormatter.ofPattern(SimpleNem12Constants.DATE_PATTERN));
	}

	private static boolean isQuantityRecValid(String col) {
		try {
			Quality.valueOf(col);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static String printArray(String[] record) {
		StringBuilder printString = new StringBuilder();
		printString.append("Record- ").append(Arrays.toString(record)).append(" - ");
		return printString.toString();
	}
}
